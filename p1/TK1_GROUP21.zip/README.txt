== Build ==
build.xml is provided in the root folder, use ant to build the project.

== Execution ==
Executables are built into dist folder.

== Running Server ==
1 command line argument is needed (server IP)
2 command line arguments are needed (server IP, host IP)
Order matters here.

When no command line argument, server and client will both run on localhost by default.
